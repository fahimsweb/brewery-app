import { combineReducers } from "redux";

import data from "./reducer";

export default combineReducers({
  data,
});
